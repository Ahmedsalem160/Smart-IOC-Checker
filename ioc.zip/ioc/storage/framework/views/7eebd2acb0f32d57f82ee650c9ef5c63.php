<?php $__env->startSection('content'); ?>
<!-- <div class="container mt-5">
    <h2 class="mb-4">Search Results for "<?php echo e($query); ?>"</h2>

    <?php if(empty($iocResults)): ?>
        <div class="alert alert-warning">
            No IOCs found for this query.
        </div>
    <?php else: ?>
    <?php $__currentLoopData = $iocResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $indicators): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h3><?php echo e(ucfirst($category)); ?></h3>
    <ul>
        <?php $__currentLoopData = array_slice($indicators, 0, 10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indicator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e(htmlspecialchars($indicator, ENT_QUOTES, 'UTF-8')); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(count($indicators) > 10): ?>
            <div style="max-height: 150px; overflow-y: auto; border: 1px solid #ccc; padding: 5px;">
                <?php $__currentLoopData = array_slice($indicators, 10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indicator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e(htmlspecialchars($indicator, ENT_QUOTES, 'UTF-8')); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endif; ?>

        <a href="<?php echo e(route('search.form')); ?>" class="btn btn-secondary mt-3">Back to Search</a>
    </div> -->


          <!-- Table -->
          <div class="w-full h-full mt-5">
        <div class="container">
          <div class="tableContainer">
            <table class="table - mb-0">
              <thead class="text-capitalize">
                <tr>
                  <th scope="col">Type</th>
                  <th scope="col">Value</th>
                  <th scope="col">Source</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $iocResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ioc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <tr>
                        <td style="text-align:center;"><?php echo e(ucfirst($type)); ?></td>
                        <td style="text-align:center;"><?php echo e($ioc); ?></td>
                        <td style="text-align:center;"><?php echo e($source); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <!--/ Table /-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmed/Public/DEBI/ioc/resources/views/search-result.blade.php ENDPATH**/ ?>