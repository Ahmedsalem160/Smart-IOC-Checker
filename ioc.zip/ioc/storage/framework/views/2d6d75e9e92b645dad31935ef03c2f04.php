<?php $__env->startSection('content'); ?>
    <!-- Hero Section -->
    <div class="heroSection">
        <div class="bgimage">
            <img src="<?php echo e(asset('assets/images/HeroSection.png')); ?>" alt="HeroSection" />
        </div>
        <h3>IOC Collection</h3>
    </div>
    <!--/ Hero Section /-->
    <!-- Search -->
    <div class="d-flex justify-content-center container">
        <div class="selectBox">
            <div class="searchBox">
                <div class="input-group border-none">
                <button
                    class="btn btn-outline-secondary dropdown-toggle"
                    type="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                >
                    All
                </button>
                <ul class="dropdown-menu">
                    <li>Hash</li>
                    <li>Ip</li>
                    <li>Domain</li>
                </ul>
                <input
                    type="text"
                    class="form-control"
                    aria-label="Text input with dropdown button"
                />
                </div>
            </div>
            <!-- search About any IOC -->
            <form action="<?php echo e(route('search.iocs')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input class="search bg-blue" value="Search" type="submit" placeholder="Enter a Search Query (e.g., WannaCry)"/>
            </form>
        </div>
    </div>
    <!--/ Search /-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmed/Public/DEBI/ioc/resources/views/welcome.blade.php ENDPATH**/ ?>